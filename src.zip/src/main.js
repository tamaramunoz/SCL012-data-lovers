/**
 * import POKEMON from './data/pokemon/pokemon.js'
 */
 import POKEMON from './data/pokemon/pokemon.js'

 console.log(POKEMON);
 
// console.log(POKEMON[4]);


//function para ordenar alfabeticamente A-Z
let orderAZ = document.getElementById("info");

const ordenAZ = (AZ) => {
let pokeData = POKEMON;
let maping = pokeData.map(nombre => nombre.name)
let sorting = maping.sort()
ordenAZ.innerHTML += sorting
};
console.log("dentro del documento");


/*
//function para ordenar Alfabeticamente al revez Z-A
let pokeData = POKEMON;
let maping = pokeData.map(element => element.name)
let sorting = maping.sort()
let reverting = sorting.reverse()
document.getElementById("info").innerHTML += reverting
console.log(reverting);*/







/* //mostrando todos los pokemones en pantalla
let pokeData = POKEMON
let resulta = " ";

pokeData.forEach( (element) => {
  let  tomandoPoke = (Object.values(POKEMON[5].name));
  document.getElementById("info").innerHTML += tomandoPoke

});
*/








/*
let nombres = POKEMON
for (const datos of POKEMON) {
  console.log(Object.values(datos))
};



for (let i = 0; i < POKEMON.length; i++) {
  let pokeData = document.getElementById("info");
  pokeData.innerHTML += 
  ` <p>${POKEMON[i].num}</p>
    <p>${POKEMON[i].name}</p> 
    <p>${POKEMON[i].type}</p>
    <p>${POKEMON[i].weaknesses}</p>`
}
    */
