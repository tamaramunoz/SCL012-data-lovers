import POKEMON from './data/pokemon/pokemon.js'
/* Manejo de data */

// esta es una función de ejemplo

export const example = () => {
  return 'example';
};


