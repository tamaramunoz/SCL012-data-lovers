
export function filterAZ() {
  let pokeData = POKEMON;
  let maping = pokeData.map(nombre => nombre.name)
  let sorting = maping.sort()
  
  
  return sorting
  };




//export const example = () => {
 // return 'example';
//};//

//todos los pokemons searching by type
//const filterByType = (data, type) => {
  //if (type === 'all') {//
    //return data;
  //}//

  //return data.filter(element) => {
    //return element.type.includes(type);
  //});//


//Buscador  by name 
//let filterByName = (data, searchText) => {
  //return data.filter(element => element.name===name)
//window.filterByType = filterByType//